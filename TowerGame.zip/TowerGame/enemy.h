#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QPoint>
#include <QPainter>
#include <QPixmap>
#include <QVector2D>

//250 600;
class Enemy : public QObject{
public:
    Enemy(){}
    Enemy(QPoint pos);
    void draw(QPainter &painter);
    void move();
    void canmove();
    QPoint getcenterPos();

private:
    QPoint _pos;
    QPixmap _pic;
    bool _canmove;

};

#endif // ENEMY_H
