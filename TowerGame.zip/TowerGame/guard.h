#ifndef GUARD_H
#define GUARD_H

#include <QPoint>
#include "towerpos.h"
#include <QPainter>
#include <QPixmap>
#include "enemy.h"
#include <QObject>
#include <math.h>

class Guard{
public:
    Guard() {}
    Guard(QPoint pos);
    void draw(QPainter &painter);
    void setPos(QPoint pos);
    QPoint getPos();
    QPoint getcenterPos();
    bool containPoint(QPoint &pos);
    bool isInAttackRange(Enemy *e);
    void attack();
    QPoint Muzzle();
    bool collinear(QPoint a, QPoint b, QPoint c);

private:
    QPoint _pos;
    QPixmap _type;
    Enemy *_target;
    bool _hasTarget;
    double _RotationAngle;
    int _velocity;

};

#endif // GUARD_H
