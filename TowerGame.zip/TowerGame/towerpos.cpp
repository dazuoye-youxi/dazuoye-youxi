#include "towerpos.h"

TowerPos::TowerPos(QPoint pos) :
    _pos(pos)
{
    _pedestal = QPixmap(":/Tpos/Tpos2.png");
    _hasGuard = false;
    _containMouse = false;
}

bool TowerPos::hasGuard(){
    return _hasGuard;
}

void TowerPos::setGuard(){
    _hasGuard = true;
}

void TowerPos::removeGuard(){
    _hasGuard = false;
}

void TowerPos::draw(QPainter &painter){
    QPixmap fixed = _pedestal.scaled(50, 50, Qt::KeepAspectRatio);

    painter.drawPixmap(_pos.x(), _pos.y(), fixed);
}

QPoint TowerPos::getPos(){
    return _pos;
}

bool TowerPos::containPoint(QPoint &pos){
    bool isXIn = (_pos.x()<pos.x() && (_pos.x()+50)>pos.x());
    bool isYIn = (_pos.y()<pos.y() && (_pos.y()+50)>pos.y());

    return (isXIn && isYIn);
}


void TowerPos::enterMouse(){
    _pedestal = QPixmap(":/Tpos/Tpos1.png");
}

void TowerPos::leaveMouse(){
    _pedestal = QPixmap(":/Tpos/Tpos2.png");
}
