#include "towerpos.h"

TowerPos::TowerPos(QPoint pos) :
    _pos(pos)
{
    _pedestal = QPixmap(":/Tpos/Tpos.png");
    _hasGuard = false;
}

bool TowerPos::hasGuard(){
    return _hasGuard;
}

void TowerPos::setGuard(){
    _hasGuard = true;
}

void TowerPos::removeGuard(){
    _hasGuard = false;
}

void TowerPos::draw(QPainter &painter){

    painter.drawPixmap(_pos.x(), _pos.y(), _pedestal);
}

QPoint TowerPos::getPos(){
    return _pos;
}

bool TowerPos::containPoint(QPoint &pos){
    bool isXIn = (_pos.x()<pos.x() && (_pos.x()+50)>pos.x());
    bool isYIn = (_pos.y()<pos.y() && (_pos.y()+50)>pos.y());

    return (isXIn && isYIn);
}
