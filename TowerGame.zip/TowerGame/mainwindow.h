#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "towerpos.h"
#include "guard.h"
#include "enemy.h"
#include <QMouseEvent>
#include <QList>
#include <QTime>
#include <QTimer>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void loadTowerPos();
    void mousePressEvent(QMouseEvent *event);

protected:
    void paintEvent(QPaintEvent *);

protected slots:
    void EnemyMove();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QList<TowerPos> Tpos;
    QList<Guard> _Guard;
    Enemy e;
};

#endif // MAINWINDOW_H
