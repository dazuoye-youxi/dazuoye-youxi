#ifndef TOWERPOS_H
#define TOWERPOS_H


#include <QPoint>
#include <QPixmap>
#include <QPainter>

class TowerPos{
public:
    TowerPos() {}
    TowerPos(QPoint pos);
    QPoint getPos();
    bool hasGuard();
    void setGuard();
    void removeGuard();
    bool containPoint(QPoint &pos);
    void draw(QPainter &painter);
    void enterMouse();
    void leaveMouse();

private:
    QPoint _pos;
    QPixmap _pedestal;
    bool _hasGuard;
    bool _containMouse;

};


#endif // TOWERPOS_H
