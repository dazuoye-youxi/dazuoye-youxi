#include "guard.h"

Guard::Guard(QPoint pos) :
    _pos(pos)
{
    _type = QPixmap(":/Tower/Tower1.png");
    _target = NULL;
    _hasTarget = false;
    _RotationAngle = 0;
    _containMouse = false;
}


void Guard::draw(QPainter &painter){
    painter.save();
    QPixmap fittype = _type.scaled(50, 50, Qt::KeepAspectRatio);
    painter.translate(getcenterPos().x(), getcenterPos().y());
    painter.rotate(_RotationAngle);
    painter.translate(-getcenterPos().x(), -getcenterPos().y());
    painter.drawPixmap(_pos.x(), _pos.y(), fittype);
    painter.restore();

    if(_containMouse){
        painter.drawEllipse(getcenterPos().x()-100, getcenterPos().y()-100, 200, 200);

    }

    painter.setPen(QPen(Qt::red));
    if(_hasTarget)
        painter.drawLine(_target->getcenterPos().x(), _target->getcenterPos().y(), getcenterPos().x(), getcenterPos().y());
    painter.setPen(QPen(Qt::black));



}

void Guard::setPos(QPoint pos){
    _pos = pos;
}

QPoint Guard::getPos(){
    return _pos;
}

QPoint Guard::getcenterPos(){
    return QPoint(_pos.x()+25, _pos.y()+25);
}

QPoint Guard::Muzzle(){
    int x = getcenterPos().x() - 20 * sin(_RotationAngle);
    int y = getcenterPos().y() + 20 * cos(_RotationAngle);
    return QPoint(x, y);

    //这个有点问题。。。
}

bool Guard::containPoint(QPoint &pos){
    bool isXIn = (_pos.x()<pos.x() && (_pos.x()+50)>pos.x());
    bool isYIn = (_pos.y()<pos.y() && (_pos.y()+50)>pos.y());

    return (isXIn && isYIn);
}

bool Guard::isInAttackRange(Enemy *e){
    int x = (e->getcenterPos().x()-getcenterPos().x());
    int y = (e->getcenterPos().y()-getcenterPos().y());
    if(sqrt(x*x + y*y) <= 100){
        _hasTarget = true;
        _target = e;
        return true;
    }
    else{
        _hasTarget = false;
        _target = NULL;
    }
    return false;
}

void Guard::attack(){
    if(_hasTarget){
        int x1 = _target->getcenterPos().x();
        int y1 = _target->getcenterPos().y();
        int x2 = getcenterPos().x();
        int y2 = getcenterPos().y();

        if(x1 == x2){
            if(y1 < y2)
                _RotationAngle = 180;
            else
                _RotationAngle = 0;
        }
        else if(y1 == y2){
            if(x1 < x2)
                _RotationAngle = 90;
            else
                _RotationAngle = -90;
        }
        else{
            if(y1 > y2){
                _RotationAngle = (atan((x2-x1)/(y1-y2))/(atan(1)*4))*180;
            }
            else{
                    _RotationAngle = 180 - (atan((x1-x2)/(y1-y2))/(atan(1)*4))*180;
            }
        }

    }
}

void Guard::enterMouse(){
    _containMouse = true;
}

void Guard::leaveMouse(){
    _containMouse = false;
}
