#include "guard.h"

Guard::Guard(QPoint pos) :
    _pos(pos)
{
    _type = QPixmap(":/Tower/Tower1.png");
    _target = NULL;
    _hasTarget = false;
    _RotationAngle = 0;
    _velocity = 1;
}


void Guard::draw(QPainter &painter){
    painter.save();
    QPixmap fittype = _type.scaled(50, 50, Qt::KeepAspectRatio);
    painter.translate(getcenterPos().x(), getcenterPos().y());
    painter.rotate(_RotationAngle);
    painter.translate(-getcenterPos().x(), -getcenterPos().y());
    painter.drawPixmap(_pos.x(), _pos.y(), fittype);
    painter.restore();
    painter.setPen(QPen(Qt::red));
    if(_hasTarget){
        painter.drawLine(_target->getcenterPos().x(), _target->getcenterPos().y(), getcenterPos().x(), getcenterPos().y());
    }


}

void Guard::setPos(QPoint pos){
    _pos = pos;
}

QPoint Guard::getPos(){
    return _pos;
}

QPoint Guard::getcenterPos(){
    return QPoint(_pos.x()+25, _pos.y()+25);
}

QPoint Guard::Muzzle(){
    int x = getcenterPos().x() - 15*sin(_RotationAngle);
    int y = getcenterPos().y() + 15*cos(_RotationAngle);
    return QPoint(x, y);
}

bool Guard::containPoint(QPoint &pos){
    bool isXIn = (_pos.x()<pos.x() && (_pos.x()+50)>pos.x());
    bool isYIn = (_pos.y()<pos.y() && (_pos.y()+50)>pos.y());

    return (isXIn && isYIn);
}

bool Guard::isInAttackRange(Enemy *e){
    int x = (e->getcenterPos().x()-getcenterPos().x());
    int y = (e->getcenterPos().y()-getcenterPos().y());
    if((x*x + y*y) <= 10000){
        _hasTarget = true;
        _target = e;
        return true;
    }
    else{
        _hasTarget = false;
        _target = NULL;
    }
    return false;
}


bool Guard::collinear(QPoint a, QPoint b, QPoint c){
    double x1, y1, x2, y2;
    x1 = a.x()-c.x();
    y1 = a.y()-c.y();
    x2 = b.x()-c.x();
    y2 = b.y()-c.y();

    if((x1*y2 - x2*y1) == 0)
        return true;

    return false;
}

void Guard::attack(){
    if(_hasTarget){
        _RotationAngle += _velocity;
    }
}
