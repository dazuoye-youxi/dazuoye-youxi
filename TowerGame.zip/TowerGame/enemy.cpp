#include "enemy.h"

Enemy::Enemy(QPoint pos) :
    QObject(0) ,
    _pos(pos)
{
    _pic = QPixmap(":/Enemy/Enemy1.png");
    _canmove = false;

}

void Enemy::draw(QPainter &painter){
    painter.drawPixmap(_pos.x(), _pos.y(), _pic);
}

void Enemy::move(){
    if(_canmove == true){
        if(_pos.y()>0){
            QPoint p(_pos.x(), _pos.y()-1);
            _pos = p;
        }
    }


}

void Enemy::canmove(){
    _canmove = true;
}

QPoint Enemy::getcenterPos(){
    return QPoint(_pos.x()+25, _pos.y()+25);
}
