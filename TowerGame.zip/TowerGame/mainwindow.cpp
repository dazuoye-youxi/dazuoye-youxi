#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QSize>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    e(QPoint(250, 550))
{
    ui->setupUi(this);
    loadTowerPos();

    connect(ui->pushButton, SIGNAL(clicked(bool)), this, SLOT(on_pushButton_clicked()));

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(EnemyMove()));
    timer->start(20);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,QPixmap(":/Map/map2.png"));
    for(int i=0 ; i<Tpos.size() ; i++){
        Tpos[i].draw(painter);
    }

    e.draw(painter);

    for(int i=0 ; i<_Guard.size() ; i++){
        Enemy *en = &e;
        _Guard[i].isInAttackRange(en);
        _Guard[i].draw(painter);

    }

}


void MainWindow::loadTowerPos(){
    QPoint pos[] = {
        QPoint(195, 200),
        QPoint(195, 400),

        QPoint(305, 200),
        QPoint(305, 400)
    };

    int len = sizeof(pos)/sizeof(pos[0]);

    for(int i=0 ; i<len ; ++i){
        Tpos.push_back(pos[i]);
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event){
    QPoint pressPos = event->pos();

    if(event->button() == Qt::LeftButton){
        for(int i=0 ; i<Tpos.size() ; i++){
            if(Tpos[i].containPoint(pressPos) && !Tpos[i].hasGuard()){
                Tpos[i].setGuard();
                _Guard.push_back(Tpos[i].getPos());
                update();
            }
        }
    }

    if(event->button() == Qt::RightButton){
        for(int i=0 ; i<Tpos.size() ; i++){
            if(Tpos[i].containPoint(pressPos) && Tpos[i].hasGuard()){
                Tpos[i].removeGuard();
                for(int j=0 ; j<_Guard.size() ; j++){
                    if(_Guard[j].containPoint(pressPos)){
                        _Guard.removeAt(j);
                        update();
                    }
                }
            }
        }
    }
}

void MainWindow::EnemyMove(){
    e.move();
    for(int i=0 ; i<_Guard.size() ; i++){
        _Guard[i].attack();
    }
    repaint();
}

void MainWindow::on_pushButton_clicked()
{
    e.canmove();
}
